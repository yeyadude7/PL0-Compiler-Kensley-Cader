/* $Id: lexer.c,v 1.5 2023/11/13 12:51:52 leavens Exp $ */

#include "lexer.h"

// All the functions declared in lexer.h are
// defined in the user code section of pl0_lexer.l
